   ___ _                  __             _    
  / __\ | ___  __ _ _ __ / /   ___   ___| | __
 / /  | |/ _ \/ _` | '__/ /   / _ \ / __| |/ /
/ /___| |  __/ (_| | | / /___| (_) | (__|   < 
\____/|_|\___|\__,_|_| \____/ \___/ \___|_|\_\
	By @NullTestfun1


ClearLock là một khóa màn hình trong suốt nhằm mục đích làm cho 
Công việc của quản trị viên hệ thống/công nghệ máy tính trở nên dễ dàng hơn bằng cách cung cấp cách tắt chức năng nhập liệu
vào máy tính trong khi vẫn cho phép bạn xem điều gì đang xảy ra. Nó hoàn toàn di động và có thể
chạy trong môi trường PE hoặc trên hệ thống trực tiếp mà không để lại bất kỳ thứ gì.


ClearLock là phần mềm miễn phí và được phân phối NGUYÊN TRẠNG mà không có bất kỳ bảo hành nào được thể hiện hay ngụ ý.


Chuyển đổi dòng lệnh:
----------------------
clearlock.exe /setpassword [password] - hiển thị hộp thoại để định cấu hình mật khẩu hoặc nếu [password] là
được cung cấp bởi dòng lệnh không có hộp thoại nào được hiển thị.

Lưu ý: Nếu không có mật khẩu nào được cấu hình, bạn sẽ được yêu cầu cấu hình một mật khẩu khi chạy
ClearLock lần đầu tiên. Bạn phải đảm bảo ClearLock ở vị trí có thể ghi được!

Clearlock.exe /config - mở hộp thoại để định cấu hình các tùy chọn
----------------------
Bạn cũng có thể tùy chỉnh ClearLock bằng cách tạo/chỉnh sửa 
ClearLock.ini nằm trong cùng thư mục với ClearLock.exe
Tất cả các trường là tùy chọn.

Vật mẫu:

[ClearLock]
;Băm mật khẩu được tạo bởi clearlock.exe /setpassword hoặc /config
Mật khẩu= 

;Thay đổi thông báo hiển thị trên màn hình khóa
DispMsg= 

;Thay đổi màu của màn hình khóa đồng nhất hoặc tông màu của màn hình khóa trong suốt [Màu hex RGB ở dạng 0x000000 (mặc định)]
Màu sắc=

; đặt thành 0 để cho phép trình bảo vệ màn hình [mặc định 1]
TắtScreenSaver= 

;Điều chỉnh độ trong suốt Giá trị: 0-255; 255 = Rắn, 0 = Vô hình [mặc định là 100]
Độ mờ = 

; đặt thành 1 để hiển thị hình nền được đặt với tham số BackgroundImage. [mặc định 0]
ShowBackgroundImage= 

;đường dẫn đầy đủ đến hình nền sẽ được hiển thị nếu ShowBackgroundImage=1 Bạn có thể sử dụng các biến môi trường (ví dụ: %SystemRoot%\myImage.bmp)
Hình nền=

;số lần thử mật khẩu không hợp lệ trước khi khóa [mặc định 3]
Khóa thử= 

;thời lượng tính bằng phút để khóa [mặc định 5]
Thời gian khóa= 

;Bật/tắt hiệu ứng âm thanh [mặc định 1]
Âm thanh=

====================================
Version 1.4.0 (9-20-2010)
====================================
[+] Hiện tại có thể sử dụng các vars môi trường trong đường dẫn BackgroundImage
[+] Đã thêm kiểm tra cấu hình chỉ đọc khi sử dụng config gui (/config)
[+] Đã thêm tùy chọn để tắt hiệu ứng âm thanh
[!] Khóa GUI giờ đây có giao diện 3D hơn
[!] Hộp thoại đặt mật khẩu giờ đây luôn được đặt lên hàng đầu
[!] Đã sửa một số lỗi chính tả trong config gui
[!] Các quy trình .ini được tối ưu hóa
[!] Đã sửa lỗi tiêu diệt taskman

====================================
Version 1.3.0 (6-22-2010)
====================================
[+] New config GUI - access by /config switch
[+] New option to disable screensaver from running while screen is locked.
[!] Tweaked lock screen GUI
[!] Lots of code cleanups/ some function rewrites.


====================================
Version 1.2.0 (4-21-2010)
====================================
[+] GUI tạo mật khẩu mới
[+] GUI nhập/khóa mật khẩu mới
[!] Dọn dẹp mã linh tinh 


=======================================
Phiên bản 1.1.0 (22-3-2010)
=======================================
[+] Đã thêm chính sách khóa. mặc định là 5 phút khóa sau 3 lần thử không hợp lệ. có thể được cấu hình trong .ini
[+] ClearLock hiện có thể chạy từ phương tiện chỉ đọc mà không cần mật khẩu được định cấu hình trước
[!] Đã sửa lỗi dịch chuyển màn hình.
[!] Đối số dòng lệnh /crypt được hợp nhất thành /setpassword
[!] Hộp thông báo bị chặn nếu số lần thử không hợp lệ là 0


=======================================
Phiên bản 1.0.0 (19-3-2010)
=======================================
[+] Bản phát hành đầu tiên


HUYỀN THOẠI
[+] - Đã thêm tính năng
[-] - Tính năng đã bị xóa
[!] - Sửa lỗi/Tinh chỉnh